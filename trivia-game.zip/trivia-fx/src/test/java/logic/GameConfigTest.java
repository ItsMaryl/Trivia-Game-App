package logic;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GameConfigTest {

    @Test
    void testEqualsAndHashCode() {
        GameConfig config1 = new GameConfig(10, "9", "easy", "multiple");
        GameConfig config2 = new GameConfig(10, "9", "easy", "multiple");
        GameConfig config3 = new GameConfig(5, "10", "hard", "boolean");

        // Ίδια αντικείμενα -> ίσα
        assertEquals(config1, config2, "Δύο ίδια GameConfig πρέπει να είναι ίσα");
        assertEquals(config1.hashCode(), config2.hashCode(), "Τα hashCodes πρέπει να ταιριάζουν");

        // Διαφορετικά αντικείμενα -> όχι ίσα
        assertNotEquals(config1, config3, "Δύο διαφορετικά GameConfig δεν πρέπει να είναι ίσα");
    }

    @Test
    void testToStringContainsValues() {
        GameConfig config = new GameConfig(10, "9", "easy", "multiple");
        String text = config.toString();

        assertTrue(text.contains("amount=10"));
        assertTrue(text.contains("category=9"));
        assertTrue(text.contains("difficulty=easy"));
        assertTrue(text.contains("type=multiple"));
    }
}
