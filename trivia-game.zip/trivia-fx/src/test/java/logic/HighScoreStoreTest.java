package logic;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HighScoreStoreTest {

    private HighScoreStore store;

    @BeforeEach
    void setUp() {
        store = new HighScoreStore();
    }

    @Test
    void testInitialScoreIsZero() {
        assertEquals(0, store.getMaxScore(), "Το αρχικό maxScore πρέπει να είναι 0");
    }

    @Test
    void testUpdateIfHigherIncreasesScore() {
        boolean updated = store.updateIfHigher(10);
        assertTrue(updated, "Πρέπει να ενημερωθεί όταν το σκορ είναι μεγαλύτερο");
        assertEquals(10, store.getMaxScore());
    }

    @Test
    void testUpdateIfHigherDoesNotUpdateForLowerScore() {
        store.updateIfHigher(15);
        boolean updated = store.updateIfHigher(5);
        assertFalse(updated, "Δεν πρέπει να ενημερωθεί όταν το σκορ είναι χαμηλότερο");
        assertEquals(15, store.getMaxScore());
    }

    @Test
    void testResetClearsScore() {
        store.updateIfHigher(20);
        GameConfig config = new GameConfig(10, "9", "easy", "multiple");
        store.reset(config);
        assertEquals(0, store.getMaxScore(), "Μετά το reset, το maxScore πρέπει να είναι 0");
    }

}
