package ui;

import app.App;
import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;
import logic.GameState;
import model.Question;

import java.util.List;

public class GameSceneCreator {

    private final double width;
    private final double height;
    private final App app;
    private final GameState state;

    public GameSceneCreator(double width, double height, App app, GameState state) {
        this.width = width;
        this.height = height;
        this.app = app;
        this.state = state;
    }

    public Scene createScene() {
        Label infoLbl = new Label();
        Label scoreLbl = new Label("Score: 0");
        Label qLbl = new Label();
        qLbl.setWrapText(true);
        qLbl.setFont(Font.font("Arial", 16));
        qLbl.setStyle("-fx-font-weight: bold;");

        Label messageLbl = new Label(); 
        messageLbl.setFont(Font.font("Arial", 14));
        messageLbl.setTextFill(Color.DARKBLUE);

        ToggleGroup group = new ToggleGroup();
        VBox optionsBox = new VBox(10);
        optionsBox.setFillWidth(true);

        Button submitBtn = new Button("Submit");
        styleButton(submitBtn, Color.GREEN);

        Button nextBtn = new Button("Next");
        styleButton(nextBtn, Color.BLUE);
        nextBtn.setDisable(true);

        Button backBtn = new Button("Back");
        styleButton(backBtn, Color.GRAY);
        backBtn.setOnAction(e -> app.backToStart());

        HBox topBar = new HBox(20, infoLbl, scoreLbl, backBtn);
        topBar.setAlignment(Pos.CENTER_LEFT);

        VBox root = new VBox(15,
                topBar,
                qLbl,
                optionsBox,
                messageLbl,
                new HBox(10, submitBtn, nextBtn)
        );
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_LEFT);

        // Φορτώνει η πρώτη ερώτηση
        loadQuestion(infoLbl, qLbl, optionsBox, group, submitBtn, nextBtn, messageLbl);

        submitBtn.setOnAction(e -> {
            RadioButton selected = (RadioButton) group.getSelectedToggle();
            if (selected == null) {
                showAnimatedMessage(messageLbl, "Διάλεξε μια απάντηση για να συνεχίσεις.", Color.ORANGE);
                return;
            }
            boolean ok = state.submitAnswer(selected.getText());
            scoreLbl.setText("Score: " + state.getScore());
            showAnimatedMessage(messageLbl, ok ? "Σωστό! (+10)" : "Λάθος. (-5)", ok ? Color.GREEN : Color.RED);

            submitBtn.setDisable(true);
            nextBtn.setDisable(false);
        });

        nextBtn.setOnAction(e -> {
            if (state.hasNext()) {
                state.goNext();
                loadQuestion(infoLbl, qLbl, optionsBox, group, submitBtn, nextBtn, messageLbl);
            } else {
            	// Τέλος παιχνιδιού
            	boolean newHigh = state.finalizeAndCheckHighScore(); 
            	
            	String msg = String.format(
            			"Τέλος!\nΣωστές: %d/%d (%.1f%%)\nΤελικό σκορ: %d%s", 
            			state.getCorrectCount(),
            			state.getTotal(),
            			state.getPercent(),
            			state.getScore(), 
            			newHigh ? "\n\n🎉 ΝΕΟ μέγιστο σκορ!" : "" 
            				);
            	Alert a = new Alert(Alert.AlertType.INFORMATION, msg); 
            	a.setHeaderText("Αποτελέσματα");
            	a.showAndWait();
            	app.backToStart(); 
            	}
            });

        return new Scene(root, width, height);
    }

    private void loadQuestion(Label infoLbl, Label qLbl, VBox optionsBox,
                              ToggleGroup group, Button submitBtn, Button nextBtn, Label messageLbl) {
        Question q = state.getCurrentQuestion();

        String header = String.format("Ερώτηση %d/%d — Δυσκολία: %s — Τύπος: %s",
                (state.getCurrentIndex() + 1), state.getTotal(),
                q.getDifficulty(), q.getType());
        infoLbl.setText(header);

        qLbl.setText(state.beautifyText(q.getQuestion()));

        optionsBox.getChildren().clear();
        group.getToggles().clear();

        List<String> options = state.getShuffledOptions(q);
        for (String opt : options) {
            RadioButton rb = new RadioButton(opt);
            rb.setToggleGroup(group);
            rb.setWrapText(true);
            rb.setFont(Font.font("Arial", 14));
            optionsBox.getChildren().add(rb);
        }

        // reset controls
        submitBtn.setDisable(false);
        nextBtn.setDisable(true);
        group.selectToggle(null);
        messageLbl.setTextFill(Color.DARKBLUE);
        messageLbl.setText("Διάλεξε απάντηση και πάτα Submit.");
        messageLbl.setOpacity(1); 
    }

    private void styleButton(Button btn, Color color) {
        btn.setStyle("-fx-background-color: " + toRgbString(color) + "; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 8;");
        btn.setOnMouseEntered(e -> btn.setStyle("-fx-background-color: " + toRgbString(color.brighter()) + "; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 8;"));
        btn.setOnMouseExited(e -> btn.setStyle("-fx-background-color: " + toRgbString(color) + "; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 8;"));
    }

    private String toRgbString(Color c) {
        return String.format("rgb(%d, %d, %d)",
                (int)(c.getRed()*255),
                (int)(c.getGreen()*255),
                (int)(c.getBlue()*255));
    }

    private void showAnimatedMessage(Label label, String text, Color color) {
        label.setTextFill(color);
        label.setText(text);

        FadeTransition ft = new FadeTransition(Duration.seconds(0.5), label);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.setCycleCount(1);
        ft.play();

        ft.setOnFinished(event -> {
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), label);
            fadeOut.setFromValue(1);
            fadeOut.setToValue(0);
            fadeOut.setDelay(Duration.seconds(2));
            fadeOut.play();
        });
    }
}
