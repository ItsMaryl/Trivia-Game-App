package ui;

import app.App;
import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;
import logic.GameConfig;
import logic.HighScoreStore;
import logic.CategoryOption;

public class StartSceneCreator {

    private final double width;
    private final double height;
    private final App app;
    private final HighScoreStore store;
    private Label maxScoreLbl; // field για εύκολη ανανέωση

    public StartSceneCreator(double width, double height, App app, HighScoreStore store) {
        this.width = width;
        this.height = height;
        this.app = app;
        this.store = store;
    }

    public Scene createScene() {
        Label title = new Label("Trivia Game");
        title.setFont(Font.font("Arial", 28));
        title.setStyle("-fx-font-weight: bold; -fx-text-fill: linear-gradient(to right, #4caf50, #2196f3);");

        FadeTransition ft = new FadeTransition(Duration.seconds(1.5), title);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();

        Spinner<Integer> spAmount = new Spinner<>(5, 20, 10);

        ComboBox<String> cbDifficulty = new ComboBox<>();
        cbDifficulty.getItems().addAll("any", "easy", "medium", "hard");
        cbDifficulty.getSelectionModel().select("any");

        ComboBox<String> cbType = new ComboBox<>();
        cbType.getItems().addAll("any", "multiple", "boolean");
        cbType.getSelectionModel().select("any");

        // ComboBox των κατηγοριών
        ComboBox<CategoryOption> cbCategory = new ComboBox<>();
        cbCategory.getItems().addAll(
            new CategoryOption("Any Category", null),
            new CategoryOption("General Knowledge", "9"),
            new CategoryOption("Books", "10"),
            new CategoryOption("Film", "11"),
            new CategoryOption("Music", "12"),
            new CategoryOption("Science & Nature", "17"),
            new CategoryOption("Sports", "21"),
            new CategoryOption("Geography", "22"),
            new CategoryOption("History", "23"),
            new CategoryOption("Art", "25"),
            new CategoryOption("Celebrities", "26"),
            new CategoryOption("Animals", "27"),
            new CategoryOption("Vehicles", "28")
        );
        cbCategory.getSelectionModel().selectFirst();

        // αναθέτουμε στο field, όχι σε τοπική μεταβλητή για να το "κρατήσει"
        maxScoreLbl = new Label("Μέγιστο σκορ (τρέχουσες ρυθμίσεις): " + store.getMaxScore());
        maxScoreLbl.setFont(Font.font(14));
        maxScoreLbl.setTextFill(Color.DARKBLUE);

        Button btnStart = new Button("Start Game");
        styleButton(btnStart, Color.ORANGE);
        btnStart.setDefaultButton(true);

        btnStart.setOnAction(e -> {
            Integer amount = spAmount.getValue();
            String difficulty = cbDifficulty.getValue();
            String type = cbType.getValue();
            CategoryOption selectedCat = cbCategory.getValue();
            String category = selectedCat != null ? selectedCat.getId() : null;

            GameConfig config = new GameConfig(amount, category, difficulty, type);
            app.startNewGame(config);
        });

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        grid.add(new Label("Πλήθος ερωτήσεων:"), 0, 0);
        grid.add(spAmount, 1, 0);
        grid.add(new Label("Δυσκολία:"), 0, 1);
        grid.add(cbDifficulty, 1, 1);
        grid.add(new Label("Τύπος:"), 0, 2);
        grid.add(cbType, 1, 2);
        grid.add(new Label("Κατηγορία:"), 0, 3);
        grid.add(cbCategory, 1, 3);

        grid.setStyle("-fx-background-color: rgba(255,255,255,0.3); -fx-padding: 15; -fx-background-radius: 10;");

        VBox root = new VBox(20, title, grid, btnStart, maxScoreLbl);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.TOP_CENTER);
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #e0f7fa, #ffe0b2);");

        return new Scene(root, width, height);
    }

    private void styleButton(Button btn, Color color) {
        btn.setStyle("-fx-background-color: " + toRgbString(color) + "; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 8;");
        btn.setOnMouseEntered(e -> btn.setStyle("-fx-background-color: " + toRgbString(color.brighter()) + "; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 8;"));
        btn.setOnMouseExited(e -> btn.setStyle("-fx-background-color: " + toRgbString(color) + "; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 8;"));
    }

    private String toRgbString(Color c) {
        return String.format("rgb(%d, %d, %d)",
                (int)(c.getRed()*255),
                (int)(c.getGreen()*255),
                (int)(c.getBlue()*255));
    }

    // Κάθε φορά που επιστρέφουμε στην αρχική οθόνη
    public void updateMaxScoreLabel() {
        if (maxScoreLbl != null) {
            maxScoreLbl.setText("Μέγιστο σκορ (τρέχουσες ρυθμίσεις): " + store.getMaxScore());
        }
    }
}
