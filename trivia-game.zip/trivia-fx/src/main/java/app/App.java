package app;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import ui.StartSceneCreator;
import ui.GameSceneCreator;
import logic.GameConfig;
import logic.GameState;
import logic.HighScoreStore;
import services.TriviaService;
import exception.TriviaAPIException;
import model.Question;
import java.util.List;

public class App extends Application {

    private Stage mainStage;
    private Scene startScene;
    private Scene gameScene;
    private StartSceneCreator startSceneCreator; // field για ανανέωση max score

    private final TriviaService triviaService = new TriviaService();
    private final HighScoreStore highScoreStore = new HighScoreStore();

    private GameConfig lastConfig = null; // για reset high score όταν αλλάζουν ρυθμίσεις

    @Override
    public void start(Stage primaryStage) {
        this.mainStage = primaryStage;
        this.mainStage.setTitle("Trivia Game - Start");

        // Δημιουργούμε και κρατάμε τον StartSceneCreator
        startSceneCreator = new StartSceneCreator(800, 500, this, highScoreStore);
        this.startScene = startSceneCreator.createScene();

        this.mainStage.setScene(startScene);
        this.mainStage.show();
    }

    // Καλείται από StartScene όταν ο χρήστης πατήσει "Start Game"
    public void startNewGame(GameConfig config) {
        try {
            // Αν άλλαξαν οι ρυθμίσεις, μηδενίζουμε το maximum
            if (lastConfig == null || !lastConfig.equals(config)) {
                highScoreStore.reset(config);
                lastConfig = config;
            }

            List<Question> questions = triviaService.getQuestions(
                    config.getAmount(),
                    config.getCategory(),
                    config.getDifficulty(),
                    config.getType()
            );

            if (questions == null || questions.isEmpty()) {
                showError("Δεν βρέθηκαν ερωτήσεις. Δοκίμασε άλλες ρυθμίσεις.");
                return;
            }

            GameState gameState = new GameState(config, questions, highScoreStore);
            GameSceneCreator gameCreator = new GameSceneCreator(900, 600, this, gameState);
            this.gameScene = gameCreator.createScene();

            this.mainStage.setTitle("Trivia Game - Playing");
            this.mainStage.setScene(gameScene);
        } catch (TriviaAPIException e) {
            showError("Σφάλμα ανάκτησης ερωτήσεων:\n" + e.getMessage());
        } catch (Exception e) {
            showError("Απρόσμενο σφάλμα:\n" + e.getMessage());
        }
    }

    // Getter για HighScoreStore
    public HighScoreStore getHighScoreStore() {
        return this.highScoreStore;
    }

    // Επιστροφή στην αρχική (ανανέωση max score)
    public void backToStart() {
        if (startSceneCreator != null) {
            startSceneCreator.updateMaxScoreLabel(); // ανανεώνουμε το label
        }
        this.mainStage.setTitle("Trivia Game - Start");
        this.mainStage.setScene(startScene);
    }

    private void showError(String msg) {
        Alert alert = new Alert(AlertType.ERROR, msg);
        alert.setHeaderText("Σφάλμα");
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
