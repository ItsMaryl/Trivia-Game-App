package logic;

import model.Question;
import org.apache.commons.text.StringEscapeUtils;
import java.util.*;

public class GameState {

    private final GameConfig config;
    private final List<Question> questions;
    private final HighScoreStore highScoreStore;

    private int index = 0;
    private int score = 0;
    private int correctCount = 0;

    public GameState(GameConfig config, List<Question> questions, HighScoreStore store) {
        this.config = config;
        this.questions = questions;
        this.highScoreStore = store;
    }

    public Question getCurrentQuestion() { return questions.get(index); }
    public int getCurrentIndex() { return index; }
    public int getTotal() { return questions.size(); }
    public int getScore() { return score; }
    public int getCorrectCount() { return correctCount; }
    public double getPercent() { return (100.0 * correctCount) / questions.size(); }
    public GameConfig getConfig() { return config; }

    public boolean hasNext() { return index < questions.size() - 1; }

    // Επιστρέφει τις επιλογές (ανακατεμένες)
    public List<String> getShuffledOptions(Question q) {
        List<String> opts = new ArrayList<>();
        if ("boolean".equalsIgnoreCase(q.getType())) {
            opts.add("True");
            opts.add("False");
        } else {
            opts.add(unesc(q.getCorrect_answer()));
            q.getIncorrect_answers().forEach(a -> opts.add(unesc(a)));
            Collections.shuffle(opts);
        }
        return opts;
    }

    // Επιστρέφει true αν η απάντηση είναι σωστή, και ενημερώνει σκορ/μετρητές
    public boolean submitAnswer(String selected) {
        Question q = getCurrentQuestion();
        String correct = "boolean".equalsIgnoreCase(q.getType())
                ? q.getCorrect_answer() // είναι "True"/"False"
                : unesc(q.getCorrect_answer());
        boolean ok = correct.equals(selected);
        if (ok) { correctCount++; score += 10; }
        else { score -= 5; }
        return ok;
    }

    public void goNext() { if (hasNext()) index++; }

    public boolean finalizeAndCheckHighScore() {
        return highScoreStore.updateIfHigher(score);
    }

    public String beautifyText(String s) { return unesc(s); }

    private String unesc(String s) {
        if (s == null) return null;
        return StringEscapeUtils.unescapeHtml4(s);
    }
}
