package logic;

public class HighScoreStore {

    private int maxScore = 0;

    public int getMaxScore() { return maxScore; }

    public boolean updateIfHigher(int newScore) {
        if (newScore > maxScore) {
            maxScore = newScore;
            return true;
        }
        return false;
    }

    public void reset(GameConfig config) {
        maxScore = 0;
    }
}
