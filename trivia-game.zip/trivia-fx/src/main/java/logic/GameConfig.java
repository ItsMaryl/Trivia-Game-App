package logic;

import java.util.Objects;

public class GameConfig {

    private final Integer amount;     // π.χ. 5..20
    private final String category;    // αριθμητικό id ως string ή null
    private final String difficulty;  // "easy","medium","hard" ή null
    private final String type;        // "multiple","boolean" ή null

    public GameConfig(Integer amount, String category, String difficulty, String type) {
        this.amount = amount;
        this.category = (category == null || category.isBlank()) ? null : category.trim();
        this.difficulty = (difficulty != null && difficulty.equalsIgnoreCase("any")) ? null : difficulty;
        this.type = (type != null && type.equalsIgnoreCase("any")) ? null : type;
    }

    public Integer getAmount() { return amount; }
    public String getCategory() { return category; }
    public String getDifficulty() { return difficulty; }
    public String getType() { return type; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GameConfig)) return false;
        GameConfig that = (GameConfig) o;
        return Objects.equals(amount, that.amount) &&
               Objects.equals(category, that.category) &&
               Objects.equals(difficulty, that.difficulty) &&
               Objects.equals(type, that.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(amount, category, difficulty, type);
    }

    @Override
    public String toString() {
        return "amount=" + amount +
               ", category=" + (category == null ? "any" : category) +
               ", difficulty=" + (difficulty == null ? "any" : difficulty) +
               ", type=" + (type == null ? "any" : type);
    }
}
