package services;

import com.fasterxml.jackson.databind.ObjectMapper;
import exception.TriviaAPIException;
import model.Question;
import model.TriviaResponse;

import java.util.List;

public class TriviaService {
    private final TriviaAPIService apiService = new TriviaAPIService();
    private final ObjectMapper mapper = new ObjectMapper();// Jackson object mapper

    public List<Question> getQuestions(int amount, String category, String difficulty, String type)
            throws TriviaAPIException {
        String json = apiService.getAPIData(amount, category, difficulty, type);
        try {
        	// JSON -> Java object 
            TriviaResponse response = mapper.readValue(json, TriviaResponse.class);
            // Το Open Trivia DB επιστρέφει response_code = 0 όταν όλα είναι καλά
            if (response.getResponse_code() != 0) {
                throw new TriviaAPIException("Το Trivia API δεν μπόρεσε να βρει ερωτήσεις (code=" + response.getResponse_code() + ")");
            }
            return response.getResults();
        } catch (Exception e) {
            throw new TriviaAPIException("Failed to parse JSON to POJO", e);
        }
    }
}
