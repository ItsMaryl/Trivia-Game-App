package services;

import model.Question;
import java.util.List;

public class TestMain {
    public static void main(String[] args) throws Exception {
        TriviaService s = new TriviaService();
        // Παράδειγμα: 5 ερωτήσεις, οποιαδήποτε κατηγορία, easy, πολλαπλής
        List<Question> qs = s.getQuestions(5, null, "easy", "multiple");
        System.out.println("Fetched: " + qs.size());
        for (Question q : qs) {
            System.out.println("- " + q.getQuestion());
        }
    }
}
