package services;

import exception.TriviaAPIException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class TriviaAPIService {

    private static final String BASE_URL = "https://opentdb.com/api.php";

    public String getAPIData(int amount, String category, String difficulty, String type)
            throws TriviaAPIException {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            StringBuilder url = new StringBuilder(BASE_URL).append("?amount=").append(amount);
            if (category != null && !category.isBlank()) url.append("&category=").append(category);
            if (difficulty != null && !difficulty.isBlank()) url.append("&difficulty=").append(difficulty);
            if (type != null && !type.isBlank()) url.append("&type=").append(type);

            HttpGet request = new HttpGet(url.toString());
            request.addHeader("Accept", "application/json");

            try (CloseableHttpResponse response = client.execute(request)) {
                String body = EntityUtils.toString(response.getEntity());
                int status = response.getStatusLine().getStatusCode();
                if (status < 200 || status >= 300) {
                    throw new TriviaAPIException("HTTP error " + status + " body: " + body);
                }
                return body;
            }
        } catch (Exception e) {
            throw new TriviaAPIException("Σφάλμα επεξεργασίας δεδομένων από το Trivia API", e);
        }
    }
}
