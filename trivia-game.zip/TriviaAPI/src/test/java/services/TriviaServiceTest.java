package services;

import model.Question;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class TriviaServiceTest {

    @Test
    public void testFetchQuestions() throws Exception {
        TriviaService s = new TriviaService();
        List<Question> qs = s.getQuestions(3, null, "easy", "boolean"); // σωστό/λάθος
        assertNotNull(qs);
        assertTrue(qs.size() > 0);
    }
}
